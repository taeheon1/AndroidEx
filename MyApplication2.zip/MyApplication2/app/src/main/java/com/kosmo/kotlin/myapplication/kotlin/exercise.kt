package com.kosmo.kotlin.myapplication.kotlin

fun main(array: Array<String>){
    val list = arrayListOf<Int>(1,2,3,4,5,6,7,8)

    list.forEach { asd -> println(asd)}

}